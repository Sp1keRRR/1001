package Radio;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class FirstSteps extends JPanel implements ActionListener {

	static String firstString = "�����";
	static String secondString = "������";
	static String thirdString = "�������";
	
	public FirstSteps() {
		super(new BorderLayout());
		
		JRadioButton firstButton = new JRadioButton(firstString);
		firstButton.setMnemonic(KeyEvent.VK_B);
		firstButton.setActionCommand(firstString);
		firstButton.setSelected(true);
		
		JRadioButton secondButton = new JRadioButton(secondString);
		secondButton.setMnemonic(KeyEvent.VK_C);
		secondButton.setActionCommand(secondString);
		
		JRadioButton thirdButton = new JRadioButton(thirdString);
		thirdButton.setMnemonic(KeyEvent.VK_D);
		thirdButton.setActionCommand(thirdString);
		
		ButtonGroup allButtons = new ButtonGroup();
		allButtons.add(firstButton);
		allButtons.add(secondButton);
		allButtons.add(thirdButton);
		
		firstButton.addActionListener(this);
		secondButton.addActionListener(this);
		thirdButton.addActionListener(this);
		
		JPanel mainPanel = new JPanel(new GridLayout(1,1));
		mainPanel.add(firstButton);
		mainPanel.add(secondButton);
		mainPanel.add(thirdButton);
		
		add(mainPanel, BorderLayout.LINE_START);
		setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
	}
	private static void createAndShowGUI() {
		JFrame frame = new JFrame("����� �������");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JComponent newContentPane = new FirstSteps();
		newContentPane.setOpaque(true);
		frame.setContentPane(newContentPane);
		
		frame.pack();
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}

package DataBase;

import static org.junit.Assert.*;

import org.junit.Test;

public class _connectionDBTest {

	@Test
	public void connection() {
		ConnectionDB cdb = new ConnectionDB();
		assertTrue("Connecting", cdb.connect());
	}
	
	@Test
	public void createTable() {
		ConnectionDB cdb = new ConnectionDB();
		assertTrue("Creatting tables", cdb.createTable());
	}
	
	@Test
	public void rowCount() {
		ConnectionDB cdb = new ConnectionDB();
		assertEquals("Row count new table", 0, cdb.getRowCountFromTable());
	}

}

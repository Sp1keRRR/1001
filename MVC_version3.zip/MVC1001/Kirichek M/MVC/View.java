package MVC;

import javax.swing.*;

public class View extends JFrame {

	   public void View(JLabel JLabel, JTextField JTextField, JButton JButton, String x)
	   {
		  JLabel= new JLabel();
		  JLabel.setBounds(34, 49, 53, 18);
	      JLabel.setText(x);
	      
	      JTextField = new JTextField();
      	  JTextField.setBounds(96, 49, 160, 20);
      	  
      	  JButton = new JButton();
      	  JButton.setBounds(103, 110, 71, 27);
      	  JButton.setText("OK");
      	  
	      this.setSize(300, 200);
	      this.getContentPane().setLayout(null);
	      this.add(JLabel);
	      this.add(JTextField);
	      this.add(JButton);
	      this.setTitle("HelloWorld");
	   }   
}
package MVC;

public class Main {

	public static void main(String[] args) {
		 Model model = retriveXDatabase(); 
		 
		 View view = new View();
		 Controller controller = new Controller(model, view);
		 view.setVisible(true);
		 
		 controller.updateView(); 
		 } 
		 
		 private static Model retriveXDatabase()
		 { 
			 Model mod = new Model(); 
			 mod.setX("Text"); 
			 return mod; 
		 }

}

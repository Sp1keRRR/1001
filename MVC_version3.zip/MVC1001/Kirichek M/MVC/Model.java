package MVC;

import javax.swing.*;

public class Model {

	private JLabel JLabel; 
	private JTextField JTextField;
	private JButton JButton;
	private String x;

	public String getX() {return x;}
	public void setX(String x) {this.x=x;} 
	
	public JLabel getJLabel() {return JLabel;}
	public void setJLabel(JLabel JLabel) {this.JLabel=JLabel;}
	
	public JTextField getJTextField() {return JTextField;}
	public void setJTextField(JTextField JTextField) {this.JTextField=JTextField;}

	public JButton getJButton() {return JButton;}
	public void setJButton(JButton JButton) {this.JButton=JButton;}

}


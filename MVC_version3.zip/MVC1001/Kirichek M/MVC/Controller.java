package MVC;

import javax.swing.*;

public class Controller{
	private Model model; 
	private View view; 
	 
	public Controller(Model model, View view)
	{ 
		this.model = model; 
		this.view = view; 
	} 
	
	//get&set
	public void setJLabel(JLabel JLabel)
	{
		model.setJLabel(JLabel);
	}
	public JLabel getJLabel()
	{ 
		return model.getJLabel(); 
	} 
	public void setJTextField(JTextField JTextField)
	{
		model.setJTextField(JTextField);
	}
	public JTextField getJTextField()
	{ 
		return model.getJTextField(); 
	} 
	public void setJButton(JButton JButton)
	{
		model.setJButton(JButton);
	}
	public JButton getJButton()
	{ 
		return model.getJButton(); 
	} 
	
	public void updateView()
	{ 
		 view.View(model.getJLabel(), model.getJTextField(), model.getJButton(), model.getX()); 
	} 
	
}

package mvc1001;

public class Main {

	public static void main(String[] args) {
		Model model = retrieveStudentFromDB();
		
		View view = new View();
		
		Controller controller = new Controller(model, view);
		
		controller.updateView();
	}
	
	private static Model retrieveStudentFromDB()
	{
		Model student = new Model();
		student.setName("Ivan");
		student.setLesson("JavaRush");
		
		return student;
	}

}

package mvc1001;

public class View {

	public void printStudentInfo(String studentName, String lesson)
	{
		System.out.println("Studient");
		System.out.println("Name: " + studentName);
		System.out.println("Studient: " + lesson);
	}

}

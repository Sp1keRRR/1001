package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDB {
	
	private Connection conn;
	private Statement statmt;
	private ResultSet resSet;
	
	public ConnectionDB() {
		
	}
	
	public boolean connect() {
		if (conn == null) { 
			try {
				Class.forName("org.sqlite.JDBC");
				try {
					conn = DriverManager.getConnection("jdbc:sqlite:test.s3db");
				} catch (SQLException e) {
					return false;
				}
			} catch (ClassNotFoundException e) {
				return false;
			}
		}
        return true;
	}

	public boolean createTable() {
		if (statmt == null) 
			if (connect() == true) {
				try {
					statmt = conn.createStatement();
					try {
						statmt.execute("CREATE TABLE if not exists 'users' ('id' INTEGER PRIMARY KEY AUTOINCREMENT, 'name' text, 'phone' INT);");
					} catch (SQLException e) {
						return false;
					}
				} catch (SQLException e) {
					return false;
				}
			}
		
		return true;
	}
	
	public int getRowCountFromTable() {
		if (createTable() == true) {
			try {
				resSet = statmt.executeQuery("SELECT COUNT(*) FROM users");
				resSet.next();
				return resSet.getInt(1);
			} catch (SQLException e) {
				return -1;
			}
		}
		return -1;
	}
}

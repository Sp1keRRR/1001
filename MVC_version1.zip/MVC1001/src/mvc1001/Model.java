package mvc1001;

public class Model {

	private String name;
	private String lesson;
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getLesson()
	{
		return lesson;
	}
	
	public void setLesson(String lesson)
	{
		this.lesson = lesson;
	}
	
}

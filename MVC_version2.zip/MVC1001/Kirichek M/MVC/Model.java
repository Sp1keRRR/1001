package MVC;

import javax.swing.*;

public class Model {

	private JLabel JLabel; 
	private JTextField JTextField;
	private JButton JButton;
	private String Text; 
	
	//Controller
	public String getText()
	{
		//Write code to copy text from JTextField
		return Text;
	}
	public void setText(String Text) {this.Text=Text;}


	//View
	public JLabel getJLabel()
	{
		if(JLabel == null) 
		{
	        	JLabel = new JLabel();
	        	JLabel.setBounds(34, 49, 53, 18);
	        	JLabel.setText("Name:");
		}
		return JLabel;
	}
	public void setJLabel(JLabel JLabel) {this.JLabel=JLabel;}

	public JTextField getJTextField()
	{
		if(JTextField == null)
		{
	        	JTextField = new JTextField();
	        	JTextField.setBounds(96, 49, 160, 20);
		}
		return JTextField;
	}
	public void setJTextField(JTextField JTextField) {this.JTextField=JTextField;}

	public JButton getJButton()
	{
		if(JButton == null)
		{
	        	JButton = new JButton();
	        	JButton.setBounds(103, 110, 71, 27);
	        	JButton.setText("OK");
		}
		return JButton;
	}
	public void setJButton(JButton JButton) {this.JButton=JButton;}

}


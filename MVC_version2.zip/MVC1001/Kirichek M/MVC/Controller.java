package MVC;

import javax.swing.*;

public class Controller{
	Model mod = new Model();	
	View view = new View();

	public void Action()
	{
		//Use getText()
	}
}

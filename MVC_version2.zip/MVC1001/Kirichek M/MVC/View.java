package MVC;

import javax.swing.*;

public class View extends JFrame {
	
	   Model mod = new Model();

	   public View()
	   {
	      super();
	      this.setSize(300, 200);
	      this.getContentPane().setLayout(null);
	      this.add(mod.getJLabel(), null);
	      this.add(mod.getJTextField(), null);
	      this.add(mod.getJButton(), null);
	      this.setTitle("HelloWorld");
	   }

	   public static void main(String[] args)
	   {
	      View w = new View();
	      w.setVisible(true);
	   }

}
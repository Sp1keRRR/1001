package Radio;

import javax.swing.JFrame;

public class ZeroClassView {

	private static void createAndShowGUI() {

		JFrame frame = new JFrame("ZeroClass");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
}
